﻿namespace ConsoleApp
{
    using System;

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Done.");
        }
    }
}
