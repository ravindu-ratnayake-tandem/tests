### The task

- [ ] Using the two sources provided, create a function that counts how many times the first character of the forename appears in both lists.
- [ ] Put invalid entries into a separate list, these are names that do not fit the pattern ```Surname, Forename```
- [ ] Names can be duplicated and in both lists. Ensure that names are not counted twice.
- [ ] Output the results to the console

#### Example Data source

    Surname, Forename
    Davidson, Paul

### Output similar to:

   * A appears 2 times 
   * B appears 4 times 
   * J appears 6 times